@extends('layouts.fo_layout')
@section('content')
    <h1><a href="{{ route('home') }}" >estás perdido volta aqui</a></h1>
@endsection