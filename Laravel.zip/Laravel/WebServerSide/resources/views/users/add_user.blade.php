@extends('layouts.fo_layout')
@section('content')
    <h1>Olá, aqui podes Adicionar Utilizadores” e associe à rota.</h1>
    <form action="">
        <input type="text" name="name" id="name" placeholder="Nome">
    </form>
@endsection